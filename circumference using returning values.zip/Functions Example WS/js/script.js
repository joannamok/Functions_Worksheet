// Joanna Mokhtarezadeh 4-30-13
//Circumference
//Calculate the Area of a Circle //Using Returning Values

var total = radius(15); //What is the radius of the circle?

function radius(r){ //value of radius
	var circumference = r * 2 * 3.14; // formula for calculating circumference
	return circumference; //return to circumference
}
console.log(" The Circumference of the cirle is"+" "+ total); //The total circumference of the circle calculate from given radius.