// Joanna Mokhtarezadeh 4-30-13
//Circumference
//Calculate the Area of a Circle 

var radius = function(diameter){
	var circumference = diameter * 2 * 3.14;
	return circumference;
}
var total = radius(15);

console.log("The circumference of the circle is"+" "+ total);