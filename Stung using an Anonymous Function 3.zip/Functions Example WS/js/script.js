// Joanna Mokhtarezadeh 4-30-13
//Stung // an Anonymous Function

//Calculates how many beestings it will take to kill an animal based on the animal's weight


var weight = function(weightAnm){ //function for calculation based on weight

	var toKill = weightAnm * 8.666666667; //calculation for total amount of beestings to kills animal

	return toKill; //return to original calculation
}
var total = weight(30); //How much does the amimal way?

var animal = "dog" //What type of animal is it? 

console.log("It takes"+" "+total+" "+"beestings to kill a"+" "+animal+"."); // This is the total amount of beestings it takes to kill the given animal.