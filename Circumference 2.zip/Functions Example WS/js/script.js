// Joanna Mokhtarezadeh 4-30-13
//Circumference
//Calculate the Area of a Circle 

var radius = function(diameter){ //calculates the circumference using by calculating the radius

	var circumference = diameter * 2 * 3.14; //formula for finding circumferance from radius
	
	return circumference; // returns to calculate circumference
}
var total = radius(15); // What is the radius of the circle? 

console.log("The circumference of the circle is"+" "+ total); // the total circumference of the circle 