// Joanna Mokhtarezadeh 4-30-13
//Stung // an Anonymous Function
//Calculates how many beestings it will take to kill an animal based on the animal's weight


var weight = function(weightAnm){
	var toKill = weightAnm * 8.666666667;
	return toKill;
}
var total = weight(30);

console.log(total);