// Joanna Mokhtarezadeh 4-30-13
//Stung // using Parameters

var animal = ("cat"); //What type of animal is this?

//Calculates how many beestings it will take to kill an animal based on the animal's weight
function weight(toKill){

	var weight = toKill * 8.66666667;	//Formula for calculating stings to kill animal  based on weight

	console.log("It takes"+" "+weight+" "+"to kill a"+" "+animal+"."); 	//The total amount of stings it takes to kill the given animal based on it's weight.
}

weight(30); //How much does this animal weigh?

