// Joanna Mokhtarezadeh 4-30-13
//Stung // using Parameters

//Calculates how many beestings it will take to kill an animal based on the animal's weight


function weight(toKill){
	var weight = toKill * 8.66666667;
	console.log(weight)
}

weight(30);